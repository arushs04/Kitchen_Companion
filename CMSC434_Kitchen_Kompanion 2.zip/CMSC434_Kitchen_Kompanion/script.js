document.addEventListener('DOMContentLoaded', function () {
    const addItemBtn = document.getElementById('add-item-btn');
    const modal = document.getElementById('modal');
    const closeModal = document.getElementById('close-modal');
    const itemForm = document.getElementById('item-form');
    const inventoryList = document.getElementById('inventory-list');
    const filterTabs = document.querySelectorAll('.tab');
    let editMode = false;
    let currentItem;

    const predefinedItems = [
        { name: 'Pear', category: 'Produce', quantity: '6 Pieces', expiryDate: '2024-11-10' },
        { name: 'Milk', category: 'Dairy', quantity: '1 Liter', expiryDate: '2024-11-05' },
        { name: 'Lamb', category: 'Meat', quantity: '500g', expiryDate: '2024-11-07' },
        { name: 'Rice', category: 'Other', quantity: '1kg', expiryDate: '2025-01-01' }
    ];

    function addItemToInventory(item) {
        const newRow = document.createElement('tr');
        newRow.classList.add('inventory-item');
        newRow.setAttribute('data-category', item.category);

        const iconCell = document.createElement('td');
        const iconImage = document.createElement('img');
        iconImage.classList.add('category-icon');
        switch (item.category) {
            case 'Produce': iconImage.src = 'assets/produce.png'; iconImage.alt = 'Produce'; break;
            case 'Dairy': iconImage.src = 'assets/dairy.png'; iconImage.alt = 'Dairy'; break;
            case 'Meat': iconImage.src = 'assets/meat.png'; iconImage.alt = 'Meat'; break;
            case 'Other': iconImage.src = 'assets/other.png'; iconImage.alt = 'Other'; break;
            default: iconImage.src = ''; iconImage.alt = '';
        }

        iconCell.appendChild(iconImage);
        newRow.appendChild(iconCell);
        
        newRow.innerHTML += `
            <td class="item-name">${item.name}</td>
            <td class="item-quantity">${item.quantity}</td>
            <td class="item-expiry" style="text-align: right;">${item.expiryDate}</td>
            <td>
                <button class="edit-btn">
                    <img src="assets/edit.png" alt="Edit" width="20" height="20">
                </button>
                <button class="delete-btn">
                    <img src="assets/delete.png" alt="Delete" width="20" height="20">
                </button>
            </td>
        `;

        newRow.querySelector('.edit-btn').addEventListener('click', function () {
            enterEditMode(newRow);
        });

        newRow.querySelector('.delete-btn').addEventListener('click', function () {
            inventoryList.removeChild(newRow);
        });

        inventoryList.appendChild(newRow);
    }

    predefinedItems.forEach(item => addItemToInventory(item));

    addItemBtn.addEventListener('click', () => {
        resetForm();
        editMode = false;
        modal.classList.remove('hidden');
    });

    closeModal.addEventListener('click', () => {
        modal.classList.add('hidden');
    });

    window.addEventListener('click', function (e) {
        if (e.target === modal) {
            modal.classList.add('hidden');
        }
    });

    itemForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const itemName = document.getElementById('item-name').value;
        const category = document.getElementById('category').value;
        const quantity = document.getElementById('quantity').value;
        const expiryDate = document.getElementById('expiry-date').value;

        if (editMode && currentItem) {
            updateRow(currentItem, { name: itemName, category, quantity, expiryDate });
        } else {
            addItemToInventory({ name: itemName, category, quantity, expiryDate });
        }

        modal.classList.add('hidden');
        resetForm();
    });

    function updateRow(row, item) {
        const iconCell = row.querySelector('td:first-child');
        iconCell.innerHTML = '';

        const iconImage = document.createElement('img');
        iconImage.classList.add('category-icon');
        switch (item.category) {
            case 'Produce': iconImage.src = 'assets/produce.png'; iconImage.alt = 'Produce'; break;
            case 'Dairy': iconImage.src = 'assets/dairy.png'; iconImage.alt = 'Dairy'; break;
            case 'Meat': iconImage.src = 'assets/meat.png'; iconImage.alt = 'Meat'; break;
            case 'Other': iconImage.src = 'assets/other.png'; iconImage.alt = 'Other'; break;
        }

        iconCell.appendChild(iconImage);
        row.querySelector('.item-name').textContent = item.name;
        row.querySelector('.item-quantity').textContent = item.quantity;
        row.querySelector('.item-expiry').textContent = item.expiryDate;
        row.setAttribute('data-category', item.category);

        editMode = false;
        currentItem = null;
    }

    filterTabs.forEach(tab => {
        tab.addEventListener('click', function () {
            const filter = this.getAttribute('data-filter');
            filterTabs.forEach(tab => tab.classList.remove('active'));
            this.classList.add('active');

            const items = document.querySelectorAll('.inventory-item');
            items.forEach(item => {
                const itemCategory = item.getAttribute('data-category');
                item.style.display = (filter === 'all' || itemCategory === filter) ? '' : 'none';
            });
        });
    });

    function enterEditMode(item) {
        editMode = true;
        currentItem = item;

        document.getElementById('item-name').value = item.querySelector('.item-name').textContent;
        document.getElementById('quantity').value = item.querySelector('.item-quantity').textContent;
        document.getElementById('expiry-date').value = item.querySelector('.item-expiry').textContent;
        document.getElementById('category').value = item.getAttribute('data-category');

        modal.classList.remove('hidden');
    }

    function resetForm() {
        document.getElementById('item-name').value = '';
        document.getElementById('quantity').value = '';
        document.getElementById('expiry-date').value = '';
        document.getElementById('category').value = 'Produce';
        editMode = false;
        currentItem = null;
    }
});


document.addEventListener('DOMContentLoaded', function () {
    const menuButton = document.getElementById('menuButton'); 
    const sidebar = document.getElementById('sidebar');       
    const closeSidebarButton = document.querySelector('.close-sidebar'); 
    

    menuButton.addEventListener('click', () => {
      sidebar.style.transform = 'translateX(0)';
    });

    closeSidebarButton.addEventListener('click', () => {
      sidebar.style.transform = 'translateX(-100%)';
    });
  });

function showTab(tab) {
    document.getElementById('suggestions-tab').style.display = tab === 'suggestions' ? 'block' : 'none';
    document.getElementById('saved-tab').style.display = tab === 'saved' ? 'block' : 'none';
    
    document.querySelectorAll('.tab').forEach(button => button.classList.remove('active'));
    document.querySelector(`.tab[onclick="showTab('${tab}')"]`).classList.add('active');
}


function saveRecipe(plusButton) {
    const recipeCard = plusButton.closest('.recipe-card');
    const savedTab = document.getElementById('saved-tab');
    const recipeId = recipeCard.getAttribute('data-id');
    const isBookmarkClose = plusButton.src.includes('assets/bookmark-close.png'); 

    const existingSavedRecipe = savedTab.querySelector(`.recipe-card[data-id="${recipeId}"]`);

    if (existingSavedRecipe && isBookmarkClose) {
        savedTab.removeChild(existingSavedRecipe);
    } else if (!existingSavedRecipe) {
        const savedRecipe = recipeCard.cloneNode(true);

        const iconImage = savedRecipe.querySelector('.icons img');
        if (iconImage) {
            iconImage.src = 'assets/bookmark-close.png';
            iconImage.alt = 'Bookmarked Icon';

            iconImage.onclick = function() {
                saveRecipe(iconImage);
            };
        }

        savedRecipe.setAttribute('data-id', recipeId);

        savedTab.appendChild(savedRecipe);
    }
}



function filterRecipes() {
    const checkboxes = document.querySelectorAll('.filter-checkbox');
    const recipeCards = document.querySelectorAll('.recipe-card');
    const activeFilters = Array.from(checkboxes)
        .filter(checkbox => checkbox.checked)
        .map(checkbox => checkbox.value);

    recipeCards.forEach(card => {
        const dietData = card.getAttribute('data-diet');
        if (activeFilters.length === 0 || activeFilters.every(filter => dietData.includes(filter))) {
            card.style.display = "flex"; 
        } else {
            card.style.display = "none";
        }
    });
}

const recipeData = {
    brownie: {
        name: "Brownie",
        ingredients: ["1 cup flour", "1/2 cup cocoa powder", "1 cup sugar", "1/2 cup oil", "1 cup water"],
        instructions: "Preheat the oven to 350°F. Mix all ingredients together until smooth. Pour into a baking dish and bake for 45 minutes."
    },
};

function openModal(recipeId) {
    const recipe = recipeData[recipeId];
    if (recipe) {
        document.getElementById("modalRecipeName").innerText = recipe.name;
        document.getElementById("modalIngredients").innerHTML = recipe.ingredients
            .map(item => `<li>${item}</li>`)
            .join("");
        document.getElementById("modalInstructions").innerText = recipe.instructions;

        const addToListButton = document.querySelector('.add-to-list');
        addToListButton.textContent = "Add to Grocery List";
        addToListButton.onclick = addCheckboxes;

        document.getElementById("recipeModal").style.display = "flex";
    }
}

function addCheckboxes() {
    const ingredientsList = document.getElementById("modalIngredients");
    const addToListButton = document.querySelector('.add-to-list'); 

    ingredientsList.innerHTML = recipeData.brownie.ingredients.map(
        ingredient => `<li><input type="checkbox"> ${ingredient}</li>`
    ).join('');

    addToListButton.textContent = "Add Items";
    addToListButton.onclick = showSuccessMessage;
}

function showSuccessMessage() {
    const successMessage = document.getElementById("successMessage");

    successMessage.classList.remove("hidden"); 
    successMessage.style.display = "block"; 

    setTimeout(() => {
        successMessage.style.display = "none";
    }, 3000);
}

document.querySelector(".close-modal").addEventListener("click", () => {
    document.getElementById("recipeModal").style.display = "none";
});

function addToShoppingList(item) {
    alert(`${item} added to your shopping list!`);
}