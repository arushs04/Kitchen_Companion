# CMSC434_Kitchen_Kompanion

Icons:
Let's just use simple icons with a black outline

Color Pallate:
Main Colors
1. White
2. Black
3. #dff2d0 
4. #b34444

We can use the last two as accent colors.

Screens:
1. Home Screen (Inventory Page) - As per feedback, this shouldn't be a generalized landing page. We need to have an actual functionality here. Let's just make this the Inventory Page
2. Recipe Suggestions Page
3. Grocery List Screen
4. Distribute Grocery shopping tasks page - We can just include this so we have 4 pages
5. Settings Screen (NOT TO INCLUDE ANYMORE) - Gloub says it's a bad idea lol

Font:
1. Roboto (Titles)
2. Helvetica (Everything else)

