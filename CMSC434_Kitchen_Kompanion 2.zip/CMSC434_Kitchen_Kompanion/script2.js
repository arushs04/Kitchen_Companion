document.addEventListener('DOMContentLoaded', function () {
    const addItemBtn = document.getElementById('add-item-btn');
    const newListBtn = document.getElementById('new-list-btn');
    const deleteListBtn = document.getElementById('delete-list-btn');
    const switchListBtn = document.getElementById('switch-list-btn');
    const confirmDeleteBtn = document.getElementById('confirm-delete-btn');
    const modalCloseBtns = document.querySelectorAll('.close-btn');
    const addItemForm = document.getElementById('add-item-form');
    const newListForm = document.getElementById('new-list-form');
    const groceryListContainer = document.getElementById("grocery-list");
    const listTitle = document.getElementById("list-title");
    const noItemsMessage = document.getElementById("no-items-message");

    let groceryLists = {};
    let currentList = "My Grocery List";
    let listToDelete = null;

    let inventory = {
        refrigerator: {},
        pantry: {},
        freezer: {},
        spiceCabinet: {},
        other: {}
    };

    groceryLists[currentList] = [];

    function updateListDisplay() {
        groceryListContainer.innerHTML = "";
        const items = groceryLists[currentList] || [];

        if (items.length === 0) {
            noItemsMessage.style.display = "block";
        } else {
            noItemsMessage.style.display = "none";
            items.forEach((item, index) => {
                const itemElement = document.createElement("div");
                itemElement.className = "grocery-item";

                itemElement.innerHTML = `
                    <div class="item-info">
                        <input type="checkbox" class="checkbox" ${item.purchased ? 'checked' : ''}>
                        <span class="item-name ${item.purchased ? 'purchased' : ''}">${item.name}</span>
                        <span class="quantity">x${item.quantity}</span>
                        ${item.location ? `<span class="location-tag">${capitalizeFirstLetter(item.location)}</span>` : ''}
                    </div>
                    <button class="delete-btn" data-index="${index}">x</button>
                `;

                const checkbox = itemElement.querySelector('.checkbox');
                checkbox.addEventListener('change', () => toggleItemPurchased(index));

                groceryListContainer.appendChild(itemElement);
            });

            const deleteButtons = groceryListContainer.querySelectorAll('.delete-btn');
            deleteButtons.forEach(button => {
                button.addEventListener('click', function () {
                    const index = this.getAttribute('data-index');
                    deleteItem(index);
                });
            });
        }
    }

    function updateInventoryDisplay() {
        const inventoryContainer = document.getElementById('inventory-container');
        inventoryContainer.innerHTML = '';

        let hasItems = false;

        Object.entries(inventory).forEach(([location, items]) => {
            if (Object.keys(items).length > 0) {
                hasItems = true;
                const section = document.createElement('div');
                section.className = 'inventory-section';

                const formattedLocation = capitalizeFirstLetter(location);

                const itemsHtml = Object.entries(items).map(([itemName, quantity]) => `
                    <div class="inventory-item">
                        <span>${itemName}</span>
                        <div class="inventory-controls">
                            <button data-location="${location}" data-item="${itemName}" data-change="-1"><i class="fas fa-minus"></i></button>
                            <span class="quantity-display">${quantity}</span>
                            <button data-location="${location}" data-item="${itemName}" data-change="1"><i class="fas fa-plus"></i></button>
                        </div>
                    </div>
                `).join('');

                section.innerHTML = `
                    <h3>${formattedLocation}</h3>
                    ${itemsHtml}
                `;

                inventoryContainer.appendChild(section);
            }
        });

        if (!hasItems) {
            const emptyMessage = document.createElement('p');
            emptyMessage.className = 'no-items-message';
            emptyMessage.textContent = 'No items in inventory. Add items from your shopping list!';
            inventoryContainer.appendChild(emptyMessage);
        }

        const inventoryButtons = inventoryContainer.querySelectorAll('.inventory-controls button');
        inventoryButtons.forEach(button => {
            button.addEventListener('click', function () {
                const location = this.getAttribute('data-location');
                const itemName = this.getAttribute('data-item');
                const change = parseInt(this.getAttribute('data-change'));
                updateQuantity(location, itemName, change);
            });
        });
    }

    addItemBtn.addEventListener('click', function () {
        openModal('add-item-modal');
    });

    newListBtn.addEventListener('click', function () {
        openModal('new-list-modal');
    });

    deleteListBtn.addEventListener('click', function () {
        deleteCurrentList();
    });

    switchListBtn.addEventListener('click', function () {
        switchList();
    });

    confirmDeleteBtn.addEventListener('click', function () {
        confirmDeleteList();
    });

    modalCloseBtns.forEach(btn => {
        btn.addEventListener('click', function () {
            const modal = this.closest('.modal');
            modal.classList.add('hidden');
        });
    });

    document.querySelectorAll('.modal').forEach(modalElement => {
        modalElement.addEventListener('click', function (e) {
            if (e.target === modalElement) {
                modalElement.classList.add('hidden');
            }
        });
    });

    addItemForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const name = document.getElementById('item-name').value;
        const quantity = parseInt(document.getElementById('item-quantity').value);
        const location = document.getElementById('item-location').value;
        const lowStock = parseInt(document.getElementById('low-stock').value);

        if (!groceryLists[currentList]) {
            groceryLists[currentList] = [];
        }

        groceryLists[currentList].push({
            name,
            quantity,
            location,
            lowStock,
            purchased: false
        });

        updateListDisplay();
        closeModal('add-item-modal');
    });

    newListForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const listName = document.getElementById('new-list-name').value.trim();
        const transferUnchecked = document.getElementById('transfer-unchecked').checked;

        if (listName) {
            let newListItems = [];
            if (transferUnchecked) {
                const unpurchasedItems = groceryLists[currentList].filter(item => !item.purchased);
                newListItems = JSON.parse(JSON.stringify(unpurchasedItems));
            }

            groceryLists[listName] = newListItems;
            currentList = listName;
            listTitle.textContent = listName;
            updateListDisplay();
        }

        closeModal('new-list-modal');
    });


    function openModal(modalId) {
        document.getElementById(modalId).classList.remove('hidden');
    }

    function closeModal(modalId) {
        document.getElementById(modalId).classList.add('hidden');
        const form = document.querySelector(`#${modalId} form`);
        if (form) form.reset();
    }

    function deleteCurrentList() {
        listToDelete = currentList;
        document.getElementById('delete-list-name').textContent = listToDelete;
        openModal('delete-list-modal');
    }

    function confirmDeleteList() {
        delete groceryLists[listToDelete];
        currentList = "My Grocery List";
        if (!groceryLists[currentList]) {
            groceryLists[currentList] = [];
        }
        listTitle.textContent = currentList;
        updateListDisplay();
        closeModal('delete-list-modal');
    }

    function switchList() {
        const listNames = Object.keys(groceryLists);
        if (listNames.length === 0) {
            alert("No lists available to switch to.");
            return;
        }

        const listNamesContainer = document.getElementById('list-names');
        listNamesContainer.innerHTML = '';

        listNames.forEach(name => {
            const listItem = document.createElement('li');
            listItem.textContent = name;
            listItem.addEventListener('click', () => {
                currentList = name;
                listTitle.textContent = name;
                updateListDisplay();
                closeModal('switch-list-modal');
            });
            listNamesContainer.appendChild(listItem);
        });

        openModal('switch-list-modal');
    }

    function updateQuantity(location, itemName, change) {
        if (!inventory[location][itemName]) {
            inventory[location][itemName] = 0;
        }

        inventory[location][itemName] += change;

        if (inventory[location][itemName] <= 0) {
            delete inventory[location][itemName];
        }

        updateInventoryDisplay();
    }

    function toggleItemPurchased(index) {
        const item = groceryLists[currentList][index];
        item.purchased = !item.purchased;

        if (item.purchased && item.location) {
            if (!inventory[item.location][item.name]) {
                inventory[item.location][item.name] = 0;
            }
            inventory[item.location][item.name] += item.quantity;
            updateInventoryDisplay();
        }

        updateListDisplay();
    }

    function deleteItem(index) {
        groceryLists[currentList].splice(index, 1);
        updateListDisplay();
    }

    window.switchTab = function(tabName) {
        document.querySelectorAll('.tab-button').forEach(button => {
            button.classList.remove('active');
        });
        document.querySelector(`.tab-button[onclick="switchTab('${tabName}')"]`).classList.add('active');

        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        document.getElementById(`${tabName}-tab`).classList.add('active');

        if (tabName === 'inventory') {
            updateInventoryDisplay();
        }
    }

    function capitalizeFirstLetter(string) {
        return string.charAt(0).toUpperCase() + string.slice(1);
    }

    updateListDisplay();
    switchTab('list');
});
