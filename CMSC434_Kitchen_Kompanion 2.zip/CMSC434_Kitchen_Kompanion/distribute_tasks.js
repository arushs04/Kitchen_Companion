let currentTask = null;

document.addEventListener('DOMContentLoaded', function() {
    let householdMembers = [
        { id: 1, name: 'Alice' },
        { id: 2, name: 'Bob' }
    ];

    let tasks = [
        { id: 1, name: 'Buy Milk', assignedTo: 1, dueDate: '2024-11-10', status: 'pending' },
        { id: 2, name: 'Get Eggs', assignedTo: 2, dueDate: '2024-11-12', status: 'completed' },
        { id: 3, name: 'Purchase Bread', assignedTo: 1, dueDate: '2024-11-15', status: 'pending' }
    ];

    const memberModal = document.getElementById('member-modal');
    const taskModal = document.getElementById('task-modal');
    const assignToSelect = document.getElementById('assign-to');
    const tasksContainer = document.getElementById('tasks-container');

    const addMemberBtn = document.getElementById('add-member-btn');
    const addTaskBtn = document.getElementById('add-task-btn');
    const closeMemberModal = document.getElementById('close-member-modal');
    const closeTaskModal = document.getElementById('close-task-modal');
    const memberForm = document.getElementById('member-form');
    const taskForm = document.getElementById('task-form');

    function updateTasksDisplay() {
        tasksContainer.innerHTML = '';
        
        tasks.forEach(task => {
            const assignedMember = householdMembers.find(member => member.id === parseInt(task.assignedTo));
            
            const row = document.createElement('tr');
            row.className = 'task-item';
            row.innerHTML = `
                <td><input type="checkbox" class="task-checkbox" ${task.status === 'completed' ? 'checked' : ''}></td>
                <td class="task-name ${task.status === 'completed' ? 'completed' : ''}">${task.name}</td>
                <td>${assignedMember ? assignedMember.name : 'Unknown'}</td>
                <td>${new Date(task.dueDate).toLocaleDateString()}</td>
                <td>
                    <button class="edit-btn"><img src="assets/edit.png" alt="Edit" width="20"></button>
                    <button class="delete-btn"><img src="assets/delete.png" alt="Delete" width="20"></button>
                </td>
            `;

            const checkbox = row.querySelector('.task-checkbox');
            checkbox.addEventListener('change', () => {
                task.status = checkbox.checked ? 'completed' : 'pending';
                row.querySelector('.task-name').classList.toggle('completed', checkbox.checked);
            });

            const editBtn = row.querySelector('.edit-btn');
            editBtn.addEventListener('click', () => editTask(task));

            const deleteBtn = row.querySelector('.delete-btn');
            deleteBtn.addEventListener('click', () => {
                tasks = tasks.filter(t => t.id !== task.id);
                updateTasksDisplay();
            });

            tasksContainer.appendChild(row);
        });
    }

    addMemberBtn.addEventListener('click', () => {
        memberModal.classList.remove('hidden');
    });

    closeMemberModal.addEventListener('click', () => {
        memberModal.classList.add('hidden');
    });

    addTaskBtn.addEventListener('click', () => {
        assignToSelect.innerHTML = '<option value="" disabled selected>Select a member</option>';
        householdMembers.forEach(member => {
            const option = document.createElement('option');
            option.value = member.id;
            option.textContent = member.name;
            assignToSelect.appendChild(option);
        });
        taskModal.classList.remove('hidden');
    });

    closeTaskModal.addEventListener('click', () => {
        taskModal.classList.add('hidden');
    });

    memberForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const memberName = document.getElementById('member-name').value;
        if (memberName) {
            householdMembers.push({ id: Date.now(), name: memberName });
            document.getElementById('member-name').value = '';
            memberModal.classList.add('hidden');
        }
    });

    function editTask(task) {
        currentTask = task;

        document.getElementById('task-name').value = task.name;
        document.getElementById('due-date').value = task.dueDate;

        assignToSelect.innerHTML = '<option value="" disabled>Select a member</option>';
        householdMembers.forEach(member => {
            const option = document.createElement('option');
            option.value = member.id;
            option.textContent = member.name;
            if (member.id === parseInt(task.assignedTo)) {
                option.selected = true;
            }
            assignToSelect.appendChild(option);
        });

        taskModal.classList.remove('hidden');
    }

    taskForm.onsubmit = (e) => {
        e.preventDefault();

        const taskName = document.getElementById('task-name').value;
        const assignedTo = document.getElementById('assign-to').value;
        const dueDate = document.getElementById('due-date').value;

        if (taskName && assignedTo && dueDate) {
            if (currentTask) {
                currentTask.name = taskName;
                currentTask.assignedTo = parseInt(assignedTo);
                currentTask.dueDate = dueDate;
                currentTask = null;
            } else {
                tasks.push({
                    id: Date.now(),
                    name: taskName,
                    assignedTo: parseInt(assignedTo),
                    dueDate,
                    status: 'pending'
                });
            }

            updateTasksDisplay();
            taskModal.classList.add('hidden');
        }
    };

    updateTasksDisplay();
});